import qrcode

# Insert a url for your qrcode
url = ''

qr = qrcode.QRCode(version=1, box_size=10, border=2)
qr.add_data(url)
qr.make(fit=True)

img = qr.make_image(fill='black', back_color='white')
# Name of qrcode image is on your choice
img.save('qrcode.png')
